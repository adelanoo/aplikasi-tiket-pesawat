<?php $__env->startSection('title', 'AdminLTE'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Pesawat</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6">
        <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title">Edit Pesawat <?php echo e($plane->code); ?></h3>
            </div>
            <!-- form start -->
            <form role="form" action="<?php echo e(url('admin/plane/'.$plane->id.'/save')); ?>">
                <div class="box-body">
                    <div class="form-group">
                        <label>Code</label>
                        <input type="text" name="code" class="form-control" id="code"
                            placeholder="Masukkan kode" value="<?php echo e($plane->code); ?>">
                    </div>
                    <div class="form-group">
                        <label>Baris Tempat Duduk</label>
                        <input type="text" class="form-control" name="seat_row" id="seat_row" placeholder="Masukkan jumlah baris"
                            value="<?php echo e($plane->seat_row); ?>">
                    </div>
                    <div class="form-group">
                        <label>Kolom tempat duduk</label>
                        <input type="text" class="form-control" name="seat_column" id="seat_column" placeholder="Masukkan jumlah kolom"
                            value="<?php echo e($plane->seat_column); ?>">
                    </div>
                    <div class="form-group">
                        <label>Select</label>
                        <select class="form-control" name="airline_id">
                            <?php $__currentLoopData = $airline; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($a->id == $plane->airline_id): ?>
                            <option value="<?php echo e($a->id); ?>" selected><?php echo e($a->name); ?></option>
                            <?php else: ?>
                            <option value="<?php echo e($a->id); ?>"><?php echo e($a->name); ?></option>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <!-- /.box-body -->

                <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>
        </div>
        <!-- /.box -->
        <?php $__env->stopSection(); ?>

        <?php $__env->startSection('js'); ?>
        <script>
            $(document).ready(function () {
                $('#table').dataTable();
            });

        </script>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\flicker-flight-api-master\resources\views/plane_detail.blade.php ENDPATH**/ ?>