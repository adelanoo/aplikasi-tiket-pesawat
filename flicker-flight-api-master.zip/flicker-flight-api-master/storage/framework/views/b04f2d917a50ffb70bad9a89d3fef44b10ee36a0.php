<?php $__env->startSection('title', 'Rute | Flicker'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Pesawat</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6">
        <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title">Edit Rute <?php echo e($route->id); ?></h3>
            </div>
            <!-- form start -->
            <form role="form" action="<?php echo e(url('admin/route/'.$route->id.'/save')); ?>">
                <div class="box-body">
                    <div class="form-group">
                        <label>Dari</label>
                        <select class="form-control" name="airport_from_id">
                            <?php $__currentLoopData = $airport; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($a->id == $route->airport_from_id): ?>
                            <option value="<?php echo e($a->id); ?>" selected><?php echo e($a->name); ?></option>
                            <?php else: ?>
                            <option value="<?php echo e($a->id); ?>"><?php echo e($a->name); ?></option>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Ke</label>
                        <select class="form-control" name="airport_to_id">
                            <?php $__currentLoopData = $airport; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($a->id == $route->airport_to_id): ?>
                            <option value="<?php echo e($a->id); ?>" selected><?php echo e($a->name); ?></option>
                            <?php else: ?>
                            <option value="<?php echo e($a->id); ?>"><?php echo e($a->name); ?></option>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Brangkat Pada:</label>
                        <div class="input-group date">
                            <div class="input-group-addon">
                                <i class="fa fa-calendar"></i>
                            </div>
                            <input name="depart_at" value="<?php echo e($route->depart_at); ?>" class="form-control datepicker" id="exampleInputEmail1" placeholder="Name">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Tiba Pada:</label>
                        <div class="input-group date">
                            <div class="input-group-addon">
                                <i class="fa fa-calendar"></i>
                            </div>
                            <input name="arrived_at" value="<?php echo e($route->arrived_at); ?>" class="form-control datepicker" id="exampleInputEmail1" placeholder="Name">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Harga</label>
                        <input type="number" class="form-control" name="price" id="price" placeholder="Masukkan harga"
                            value="<?php echo e($route->price); ?>">
                    </div>
                    <div class="form-group">
                        <label>Pesawat</label>
                        <select class="form-control" name="plane_id">
                            <?php $__currentLoopData = $plane; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($a->id == $route->plane_id): ?>
                            <option value="<?php echo e($a->id); ?>" selected><?php echo e($a->code); ?> (<?php echo e($a->airline->name); ?>)</option>
                            <?php else: ?>
                            <option value="<?php echo e($a->id); ?>"><?php echo e($a->code); ?> (<?php echo e($a->airline->name); ?>)</option>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>
        </div>
        <!-- /.box -->
        <?php $__env->stopSection(); ?>

        <?php $__env->startSection('js'); ?>
        <script>
            $(document).ready(function () {
                $('#table').dataTable();
            });
			$( function() {
	$(".datepicker").datetimepicker({format : "YYYY-MM-DD HH:mm:ss"});
  } );

        </script>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\flicker-flight-api-master\resources\views/route_detail.blade.php ENDPATH**/ ?>