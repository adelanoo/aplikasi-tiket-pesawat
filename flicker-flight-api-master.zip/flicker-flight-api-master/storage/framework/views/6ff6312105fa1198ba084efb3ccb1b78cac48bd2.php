<?php $__env->startSection('title', 'Pelanggan | Flicker'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Pelanggan</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6">
        <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title">Edit Pelanggan <?php echo e($customer->code); ?></h3>
            </div>
            <!-- form start -->
            <form role="form" action="<?php echo e(url('admin/customer/'.$customer->id.'/save')); ?>">
                <div class="box-body">
                    <div class="form-group">
                        <label>Email</label>
                        <input type="text" name="email" class="form-control" id="email"
                            placeholder="Masukkan email" value="<?php echo e($customer->email); ?>">
                    </div>
                    <div class="form-group">
                        <label>Nama</label>
                        <input type="text" class="form-control" name="name" id="name" placeholder="Masukkan nama"
                            value="<?php echo e($customer->name); ?>">
                    </div>
                    <div class="form-group">
                        <label>Alamat</label>
                        <input type="text" class="form-control" name="address" id="address" placeholder="Masukkan jumlah kolom"
                            value="<?php echo e($customer->address); ?>">
                    </div>
                    <div class="form-group">
                        <label>Phone</label>
                        <input type="text" class="form-control" name="phone" id="phone" placeholder="Masukkan jumlah kolom"
                            value="<?php echo e($customer->phone); ?>">
                    </div>
                    <div class="form-group">
                        <label>Select</label>
                        <select class="form-control" name="gender_id">
                            <?php $__currentLoopData = $gender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($a->id == $customer->gender_id): ?>
                            <option value="<?php echo e($a->id); ?>" selected><?php echo e($a->name); ?></option>
                            <?php else: ?>
                            <option value="<?php echo e($a->id); ?>"><?php echo e($a->name); ?></option>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <!-- /.box-body -->

                <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>
        </div>
        <!-- /.box -->
        <?php $__env->stopSection(); ?>

        <?php $__env->startSection('js'); ?>
        <script>
            $(document).ready(function () {
                $('#table').dataTable();
            });

        </script>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\flicker-flight-api-master\resources\views/customer_detail.blade.php ENDPATH**/ ?>