<?php $__env->startSection('title', 'Pemesanan | Flicker'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Pesanan</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="box box-primary">
    <div class="box-header with-border">
        <h1 class="box-title">Cari Data Pemesanan</h1>
        <div class="box-tools pull-right">
            <!-- <a href="<?php echo e(url('admin/route/new')); ?>"><button class="btn btn-success">Tambah</button></a> -->
        </div>
    </div>
    <div class="box-body">
        <table id="table" class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Kode Pemesanan</th>
                    <th>Tanggal Pemesanan</th>
                    <th>Rute</th>
                    <th>Nama Pemesan</th>
                    <th>Harga</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $reservation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($a->id); ?></td>
                    <td><?php echo e($a->res_code); ?></td>
                    <td><?php echo e($a->res_date); ?></td>
                    <td><?php echo e($a->res_loc); ?> - <?php echo e($a->destination->name); ?></td>
                    <td><?php echo e($a->customer->name); ?> (<?php echo e($a->name); ?>)</td>
                    <td><?php echo e($a->cost); ?></td>
                    <td><?php echo e($a->status->name); ?></td>
                    <td>
                        <a href="<?php echo e(url('admin/reservation/'.$a->id)); ?>">
                            <i class="fa fa-pencil"></i>
                        </a>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <!-- <a href="<?php echo e(url('admin/reservation/'.$a->id.'/delete')); ?>">
                            <i class="fa fa-trash"></i>
                        </a> -->
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div><!-- /.box-body -->
    <div class="box-footer">
        The footer of the box
    </div><!-- box-footer -->
</div><!-- /.box -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function () {
        $('#table').dataTable();
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\flicker-flight-api-master\resources\views/reservation.blade.php ENDPATH**/ ?>