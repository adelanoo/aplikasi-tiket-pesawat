<?php $__env->startSection('title', 'Bandara | Flicker'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Bandara</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6">
        <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title">Edit Bandara <?php echo e($airport->name); ?></h3>
            </div>
            <!-- form start -->
            <form role="form" action="<?php echo e(url('admin/airport/'.$airport->id.'/update')); ?>">
                <div class="box-body">
                    <div class="form-group">
                        <label>Nama</label>
                        <input type="text" name="name" class="form-control" id="name" placeholder="Masukkan nama bandara" value="<?php echo e($airport->name); ?>">
                    </div>
                    <div class="form-group">
                        <label>Kode</label>
                        <input type="text" class="form-control" name="code" id="code" placeholder="Masukkan kode" value="<?php echo e($airport->code); ?>">
                    </div>
                    <div class="form-group">
                        <label>Kota</label>
                        <input type="text" class="form-control" name="city" id="city" placeholder="Masukkan kota" value="<?php echo e($airport->city); ?>">
                    </div>
                    <div class="form-group">
                        <label>Alamat</label>
                        <textarea type="text" class="form-control" name="address" id="address" placeholder="Masukkan alamat"><?php echo e($airport->address); ?></textarea>
                    </div>
                </div>
                <!-- /.box-body -->

                <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>
        </div>
        <!-- /.box -->
        <?php $__env->stopSection(); ?>

        <?php $__env->startSection('js'); ?>
        <script>
            $(document).ready(function () {
                $('#table').dataTable();
            });

        </script>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\flicker-flight-api-master\resources\views/airport_edit.blade.php ENDPATH**/ ?>